using UnityEngine;
using UnityEngine.EventSystems;

public class TouchManager : MonoBehaviour, IPointerDownHandler
{
    [SerializeField] private bool touch = false;

    private Canvas canvas;
    private RectTransform canvasRectT;

    private RectTransform rectT;

    Vector2 dif;
    private bool init = false;

    void Start()
    {
        //canvas����rectTransform�ɕϊ�
        canvas = this.transform.parent.GetComponent<Canvas>();
        canvasRectT = canvas.GetComponent<RectTransform>();
        //���̃I�u�W�F�N�g��UI�p���W
        rectT = GetComponent<RectTransform>();
    }

    void Update()
    {
        Drag();
    }

    /// <summary>
    /// ����UI�𓮂���
    /// </summary>
    void Drag()
    {
        if (touch)
        {
            //�}�E�X�̍��W��canvas�̃��[�J�����W�ɕϊ�
            Vector2 localPos;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRectT,
                                                                    Input.mousePosition,
                                                                    canvas.worldCamera,
                                                                    out localPos);
            if (init == false)
            {
                dif = rectT.anchoredPosition - localPos;
                init = true;
            }

            //�ϊ��������W����
            rectT.anchoredPosition = localPos + dif;

            if (Input.GetMouseButtonUp(0))
            {
                touch = false;
                init = false;
            }
        }
    }

    /// <summary>
    /// ����UI���N���b�N��������s
    /// </summary>
    public void OnPointerDown(PointerEventData eventData)
    {
        touch = true;
        Debug.Log(gameObject.name);
    }
}
