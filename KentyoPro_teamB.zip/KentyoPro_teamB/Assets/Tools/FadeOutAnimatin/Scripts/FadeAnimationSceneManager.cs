using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class FadeAnimationSceneManager : SingletonMonoBehaviour<FadeAnimationSceneManager>
{
    private GameObject FadeAnimation;
    private Image _i;

    public bool FadeIn;
    public float interval;
    [Space]
    public bool FadeOut;

    private bool f;
    private string s;
    private float i;

    private float t;
    private bool animating_out;
    private bool animating_in;
    private void Start()
    {
        FadeAnimation = GameObject.Find("FadeAnimation");
        _i = FadeAnimation.GetComponent<Image>();
        t = 0;
        animating_in = true;
        if (FadeIn == true)
            _i.color = new Color32(0, 0, 0, 255);
    }

    private void Update()
    {
        FadeInAnimation();

        if (f == true && animating_in == false)
            FadeOutAnimation(s, i);
    }

    void FadeInAnimation()
    {
        if (FadeIn == true && animating_in == true)
        {
            this.gameObject.transform.localScale = new Vector3(1, 1, 1);
            t += Time.deltaTime;
            float a = 1 - 1 * t / interval;
            if (a <= 0)
                a = 0;
            _i.color = new Color(0, 0, 0, a);

            if (interval < t)
            {
                gameObject.transform.localScale = new Vector3(0, 0, 0);
                animating_in = false;
                t = 0;
            }
        }
    }
    void FadeOutAnimation(string Scene_name, float outInterval)
    {
        FadeAnimation = GameObject.Find("FadeAnimation");
        _i = FadeAnimation.GetComponent<Image>();
        //�t�F�C�h�A�E�g���̏���
        if (FadeOut == true)
        {
            FadeAnimation.gameObject.transform.localScale = new Vector3(1, 1, 1);
            t += Time.deltaTime;
            //�C���^�[�o����t�̊����Ń��F���v�Z���ďo��
            float a = 1.0f *  t / outInterval;
            if (1 <= a)
                a = 1;

            _i.color = new Color(0, 0, 0, a);

            //�A�j���[�V���������Ă��邩�ǂ���
            if (t <= outInterval) animating_out = true;
            else
            {
                animating_out = false;
                t = 0;
            }
        }

        //�A�j���[�V�������I�������V�[����؂�ւ���
        if (animating_out == false)
        {
            SceneManager.LoadScene(Scene_name);
        }
    }
    public void LoadScene(string Scene_name, float Interval)
    {
        //���̖��O�̃V�[�������邩���ׂ�
        if (SceneUtility.GetBuildIndexByScenePath(Scene_name) == -1)
        {
            //�G���[�R�[�h
            Debug.LogError(Scene_name + "�͑��݂��Ȃ��V�[���ł��B");
        }
        else
        {
            s = Scene_name;
            i = Interval;
            f = true;
        }
    }
}