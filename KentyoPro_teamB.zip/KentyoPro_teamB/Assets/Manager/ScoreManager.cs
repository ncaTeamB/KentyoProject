using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ScoreManager : SingletonMonoBehaviour<ScoreManager>
{
    [Header("�X�R�A�\���p�e�L�X�g")]
    [SerializeField] private TextMeshProUGUI scoreText;
    public static int score;

    [Space]
    [Header("�����L���O�\���p�e�L�X�g")]
    [SerializeField] private TextMeshProUGUI[] rankingText;

    [Space]
    [SerializeField] private LeaderBoardManager leaderBoard;
    public static int hightScore;

    void Start()
    {
        //�^�C�g���V�[���̎��̂ݎ��s
        if (SceneManager.GetActiveScene().name == "TitleScene")
        {
            hightScore = leaderBoard.GetMyBestScore();
        }
        //�Q�[���V�[���̎��̂ݎ��s
        else if (SceneManager.GetActiveScene().name == "GameScene")
        {
            score = 0;
            scoreText.text = $"Score:{score}";
        }
        //���U���g�V�[���̎��̂ݎ��s
        else if (SceneManager.GetActiveScene().name == "ResultScene")
        {
            scoreText.text = $"{score}";
            leaderBoard.SetMyScore(score);

            int[] scores = leaderBoard.GetScores();
            string[] ids = leaderBoard.GetIds();
            string myid = leaderBoard.GetMyId();
            int j = 0;
            bool intoMine = false;
            int l = scores.Length;

            Debug.Log(l);
            for (int i = 0; i < l; i++)
            {
                //�����̃X�R�A�������L���O�ɏ���Ă�ꍇ
                if (ids[i] == myid)
                {
                    if (intoMine == false)
                        if (leaderBoard.GetMyBestScore() < score)
                            rankingText[i].text = $"{i + 1}��:{score}";
                        else
                            rankingText[i].text = $"{i + 1}��:{scores[i]}";

                    intoMine = true;

                    continue;
                }
                //�����̃X�R�A���ق��̐l��荂���ꍇ
                if (intoMine == false && scores[i] < score)
                {
                    rankingText[i].text = $"{i + 1}��:{score}";
                    intoMine = true;
                    j = 1;
                }
                else if(0 < j)
                    rankingText[i].text = $"{i + 1}��:{scores[i - j]}";
                else
                    rankingText[i].text = $"{i + 1}��:{scores[i]}";

                if (l <= i + j)
                    break;
            }
        }
    }

    public void AddScore(int addPoint)
    {
        score += addPoint;
        if (scoreText != null)
            scoreText.text = $"Score:{score}";
    }
}
