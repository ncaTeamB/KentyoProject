using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ScoreManager : SingletonMonoBehaviour<ScoreManager>
{
    [Header("�X�R�A�\���p�e�L�X�g")]
    [SerializeField] private TextMeshProUGUI scoreText;
    public static int score;

    [Space]
    [Header("�����L���O�\���p�e�L�X�g")]
    [SerializeField] private TextMeshProUGUI[] rankingText = new TextMeshProUGUI[5];

    [Space]
    [SerializeField] private LeaderBoardManager leaderBoard;

    public static int hightScore = 0;

    private Color rankColor;

    void Start()
    {
        //�^�C�g���V�[���̎��̂ݎ��s
        if (SceneManager.GetActiveScene().name == "TitleScene")
        {
            rankColor = Color.black;

            if (hightScore <= 0)
                hightScore = leaderBoard.GetMyBestScore();
        }
        //�Q�[���V�[���̎��̂ݎ��s
        else if (SceneManager.GetActiveScene().name == "GameScene")
        {
            score = 0;
            scoreText.text = $"Score:{score}";
        }
        //���U���g�V�[���̎��̂ݎ��s
        else if (SceneManager.GetActiveScene().name == "ResultScene")
        {
            rankColor = Color.black;
            scoreText.text = $"{score}";
            DrawRanking();
        }
    }

    public void DrawRanking()
    {
        int[] scores = leaderBoard.GetScores();
        string[] names = leaderBoard.GetNames();
        string[] ids = leaderBoard.GetIds();

        string myid = leaderBoard.GetMyId();

        int j = 0;
        bool intoMine = false;
        bool updateMyBestScore = false;
        //�n�C�X�R�A���X�V������
        if (hightScore < score)
        {
            updateMyBestScore = true;
            hightScore = score;
        }

        for (int i = 0; i < scores.Length; i++)
        {
            //�����̃X�R�A���n�C�X�R�A����Ȃ�������
            if (updateMyBestScore == false)
            {
                rankingText[i].color = rankColor;
                rankingText[i].text = $"{names[i]} {scores[i]}";
                //�����̂Ȃ�
                if (ids[i] == myid)
                {
                    rankingText[i].color = Color.yellow;
                    rankingText[i].fontStyle = FontStyles.Bold;
                    rankingText[i].text = $"���Ȃ� {hightScore}";
                }

                continue;
            }

            //�����̃X�R�A�������L���O�ɏ���Ă�ꍇ
            if (ids[i + j] == myid)
            {
                if (intoMine == false)
                {
                    rankingText[i].color = Color.yellow;
                    rankingText[i].fontSize = 60;
                    rankingText[i].text = $"���Ȃ� {hightScore}";
                }
                else
                {
                    j = 0;
                    rankingText[i].color = rankColor;
                    //�����̂���΂��Ď��̏��ʂ̐l�̂�����
                    rankingText[i].text = $"{names[i + j]} {scores[i + j]}";
                }

                intoMine = true;
            }
            //�����̃X�R�A���ق��̐l��荂���ꍇ
            else if (intoMine == false && scores[i] < score)
            {
                rankingText[i].color = Color.yellow;
                rankingText[i].fontSize = 60;
                rankingText[i].text = $"���Ȃ� {score}";
                intoMine = true;
                j = -1;
            }
            else
            {
                rankingText[i].color = rankColor;
                rankingText[i].text = $"{names[i + j]} {scores[i + j]}";
            }
        }

        leaderBoard.SetMyScore(score);
    }

    public void AddScore(int addPoint)
    {
        score += addPoint;
        if (scoreText != null)
            scoreText.text = $"Score:{score}";
    }
}
