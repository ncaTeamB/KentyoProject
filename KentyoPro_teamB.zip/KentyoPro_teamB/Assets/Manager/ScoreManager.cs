using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ScoreManager : SingletonMonoBehaviour<ScoreManager>
{
    [Header("�X�R�A�\���p�e�L�X�g")]
    [SerializeField] private TextMeshProUGUI scoreText;
    public static int score;

    void Start()
    {
        //�Q�[���V�[���̎��̂ݎ��s
        if (SceneManager.GetActiveScene().name == "GameScene")
        {
            score = 0;
        }
        scoreText.text = $"Score:{score}";
    }

    public void AddScore(int addPoint)
    {
        score += addPoint;
        if (scoreText != null)
            scoreText.text = $"Score:{score}";
    }
}
