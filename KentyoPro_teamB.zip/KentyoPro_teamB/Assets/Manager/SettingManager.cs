using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SettingManager : MonoBehaviour
{
    private GameObject panel;
    //�T�E���h�I���{�^���Ɖ摜
    private GameObject volOnBtn;
    private GameObject volOnImg;
    //�T�E���h�I�t�{�^���Ɖ摜
    private GameObject volOffBtn;
    private GameObject volOffImg;
    private Color SelectedColor;
    private Color OriginColor;

    void Start()
    {
        panel = this.transform.GetChild(0).gameObject;
        panel.SetActive(false);

        float a = 200.0f / 255.0f;
        SelectedColor = new Color(a, a, a);
        OriginColor = new Color(1, 1, 1);
        volOnBtn = panel.transform.Find("VolOnBtn").gameObject;
        volOnImg = panel.transform.Find("VolOnImg").gameObject;
        volOffBtn = panel.transform.Find("VolOffBtn").gameObject;
        volOffImg = panel.transform.Find("VolOffImg").gameObject;

        if (SoundManager.vol == true)
            SetVolOnProc();
        else
            SetVolOffProc();
    }

    /// <summary>
    /// �T�E���h�I���{�^�����������Ƃ��̏���
    /// </summary>
    void SetVolOnProc()
    {
        volOnBtn.GetComponent<Image>().color = SelectedColor;
        volOnBtn.GetComponent<Button>().enabled = false;
        volOnImg.GetComponent<Image>().color = SelectedColor;

        volOffBtn.GetComponent<Image>().color = OriginColor;
        volOffBtn.GetComponent<Button>().enabled = true;
        volOffImg.GetComponent<Image>().color = OriginColor;
    }

    /// <summary>
    /// �T�E���h�I�t�{�^�����������Ƃ��̏���
    /// </summary>
    void SetVolOffProc()
    {
        volOnBtn.GetComponent<Image>().color = OriginColor;
        volOnBtn.GetComponent<Button>().enabled = true;
        volOnImg.GetComponent<Image>().color = OriginColor;

        volOffBtn.GetComponent<Image>().color = SelectedColor;
        volOffBtn.GetComponent<Button>().enabled = false;
        volOffImg.GetComponent<Image>().color = SelectedColor;
    }

    /// <summary>
    /// �ݒ�{�^�����������Ƃ�
    /// </summary>
    public void OnClickSettingBtn()
    {
        //�\����\���؂�ւ�
        if (panel.activeSelf == true)
        {
            panel.SetActive(false);
            if (SceneManager.GetActiveScene().name == "GameScene")
            {
                GameManager.Instance.stopTimer = false;
                GameManager.Instance.ready = true;
            }
        }
        else
        {
            panel.SetActive(true);
            if (SceneManager.GetActiveScene().name == "GameScene")
            {
                GameManager.Instance.stopTimer = true;
                GameManager.Instance.ready = false;
            }
        }
    }

    public void OnClickBackTitleBtn()
    {
        FadeAnimationSceneManager.Instance.LoadScene("TitleScene", 1);
    }

    public void OnClickCloseBtn()
    {
        panel.SetActive(false);
        if (SceneManager.GetActiveScene().name == "GameScene")
        {
            GameManager.Instance.stopTimer = false;
            GameManager.Instance.ready = true;
        }
    }

    public void OnClickRestartBtn()
    {
        FadeAnimationSceneManager.Instance.LoadScene("GameScene", 1);
    }

    public void OnClickVolOnBtn()
    {
        SoundManager.vol = true;
        SetVolOnProc();
    }

    public void OnClickVolOffBtn()
    {
        SoundManager.vol = true;
        SetVolOffProc();
    }
}
