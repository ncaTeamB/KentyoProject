using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SettingManager : MonoBehaviour
{
    private GameObject panel;

    void Start()
    {
        panel = this.transform.GetChild(0).gameObject;
        panel.SetActive(false);
        GameManager.Instance.stopTimer = false;
    }

    /// <summary>
    /// �ݒ�{�^�����������Ƃ�
    /// </summary>
    public void OnClickSettingBtn()
    {
        //�\����\���؂�ւ�
        if (panel.activeSelf == true)
        {
            panel.SetActive(false);
            GameManager.Instance.stopTimer = false;
        }
        else
        {
            panel.SetActive(true);
            GameManager.Instance.stopTimer = true;
        }
    }

    public void OnClickBackTitleBtn()
    {
        SceneManager.LoadScene("TitleScene");
    }

    public void OnClickCloseBtn()
    {
        panel.SetActive(false);
        GameManager.Instance.stopTimer = false;
    }
}
