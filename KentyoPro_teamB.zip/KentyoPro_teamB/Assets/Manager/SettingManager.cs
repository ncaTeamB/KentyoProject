using UnityEngine;
using UnityEngine.SceneManagement;

public class SettingManager : MonoBehaviour
{
    private GameObject panel;

    void Start()
    {
        panel = this.transform.GetChild(0).gameObject;
        panel.SetActive(false);
    }

    /// <summary>
    /// �ݒ�{�^�����������Ƃ�
    /// </summary>
    public void OnClickSettingBtn()
    {
        //�\����\���؂�ւ�
        if (panel.activeSelf == true)
        {
            panel.SetActive(false);
            if (SceneManager.GetActiveScene().name == "GameScene")
            {
                GameManager.Instance.stopTimer = false;
                GameManager.Instance.ready = true;
            }
        }
        else
        {
            panel.SetActive(true);
            if (SceneManager.GetActiveScene().name == "GameScene")
            {
                GameManager.Instance.stopTimer = true;
                GameManager.Instance.ready = false;
            }
        }
    }

    public void OnClickBackTitleBtn()
    {
        FadeAnimationSceneManager.Instance.LoadScene("TitleScene", 1);
    }

    public void OnClickCloseBtn()
    {
        panel.SetActive(false);
        if (SceneManager.GetActiveScene().name == "GameScene")
        {
            GameManager.Instance.stopTimer = false;
            GameManager.Instance.ready = true;
        }
    }

    public void OnClickRestartBtn()
    {
        FadeAnimationSceneManager.Instance.LoadScene("GameScene", 1);
    }

    public void OnClickVolOnBtn()
    {

    }

    public void OnClickVolOffBtn()
    {

    }
}
