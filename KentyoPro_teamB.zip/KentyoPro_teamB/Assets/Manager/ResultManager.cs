using UnityEngine;
using UnityEngine.SceneManagement;

public class ResultManager : MonoBehaviour
{
    public void OnClickRestart()
    {
        SceneManager.LoadScene("GameScene");
    }

    public void OnClickTitle()
    {
        SceneManager.LoadScene("TitleScene");
    }
}
