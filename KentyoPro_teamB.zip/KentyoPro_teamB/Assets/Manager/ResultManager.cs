using UnityEngine;
using UnityEngine.SceneManagement;

public class ResultManager : MonoBehaviour
{
    public void OnClickRestart()
    {
        FadeAnimationSceneManager.Instance.LoadScene("GameScene", 1);
    }

    public void OnClickTitle()
    {
        FadeAnimationSceneManager.Instance.LoadScene("TitleScene", 1);
    }
}
