using Newtonsoft.Json;
using UnityEngine;

public class WarnigScreenManager : MonoBehaviour
{
    private void Start()
    {
        Invoke("LoadTitleScene", 2);
    }

    void LoadTitleScene()
    {
        FadeAnimationSceneManager.Instance.LoadScene("TitleScene", 1);
    }
}
