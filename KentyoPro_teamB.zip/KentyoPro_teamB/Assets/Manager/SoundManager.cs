using UnityEngine;

public class SoundManager : SingletonMonoBehaviour<SoundManager>
{
    public static bool vol = true;


    void Update()
    {

    }

    public void OnClickVolOffBtn()
    {
        vol = false;
    }

    public void OnClickVolOnBtn()
    {
        vol = true;
    }
}
