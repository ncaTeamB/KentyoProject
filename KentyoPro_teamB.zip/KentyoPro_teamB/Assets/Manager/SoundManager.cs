using UnityEngine;

public class SoundManager : MonoBehaviour
{
    public static bool vol;

    void Start()
    {
        vol = true;
    }


    void Update()
    {

    }

    public void OnClickVolOffBtn()
    {
        vol = false;
    }

    public void OnClickVolOnBtn()
    {
        vol = true;
    }
}
