using UnityEngine;
using UnityEngine.SceneManagement;

public class TitleManager : MonoBehaviour
{
    void Start()
    {
        //unity�ݒ�
        Application.targetFrameRate = 60;
        QualitySettings.vSyncCount = 0;
    }

    public void OnClickStartBtn()
    {
        SceneManager.LoadScene("GameScene");
    }
}
