using TMPro;
using UnityEngine;

public class TitleManager : MonoBehaviour
{
    [Header("�����L���O�{�[�h")]
    [SerializeField] private GameObject rankingBoard;

    [Space]
    [Header("���g�̖��O�\���p")]
    [SerializeField] private TextMeshProUGUI nameText;
    [SerializeField] private TextMeshProUGUI renameSpace;
    private GameObject renameObj;

    [Space]
    [SerializeField] private LeaderBoardManager leaderBoardManager;

    void Start()
    {
        //unity�ݒ�
        Application.targetFrameRate = 60;
        QualitySettings.vSyncCount = 0;

        renameObj = renameSpace.gameObject.transform.parent.parent.gameObject;
        renameObj.SetActive(false);
    }

    private void Update()
    {
        nameText.text = $"{leaderBoardManager.GetMyName()}";
    }

    public void OnClickStartBtn()
    {
        FadeAnimationSceneManager.Instance.LoadScene("GameScene", 1);
    }

    public void OnClickRenameBtn()
    {
        if (renameObj.activeSelf == false)
        {
            renameObj.SetActive(true);
        }
        else
            leaderBoardManager.SetName(renameSpace.text);
    }

    public void OnClickRankingBtn()
    {
        ScoreManager.Instance.DrawRanking();

        if (rankingBoard.activeSelf == false)
            rankingBoard.SetActive(true);
        else
            rankingBoard.SetActive(false);
    }

    public void OpenKeyboard()
    {
        TouchScreenKeyboard.Open("", TouchScreenKeyboardType.Default);
    }
}
