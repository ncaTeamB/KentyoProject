using UnityEngine;

public class TitleManager : MonoBehaviour
{
    void Start()
    {
        //unity�ݒ�
        Application.targetFrameRate = 60;
        QualitySettings.vSyncCount = 0;
    }

    public void OnClickStartBtn()
    {
        FadeAnimationSceneManager.Instance.LoadScene("GameScene", 1);
    }
}
