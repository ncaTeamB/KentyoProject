using TMPro;
using UnityEngine;

public class GameManager : SingletonMonoBehaviour<GameManager>
{
    [SerializeField] private TextMeshProUGUI scoreText;

    public float deltaTime;

    public float score;

    private void Start()
    {
        score = 0;
    }

    void Update()
    {
        deltaTime = Time.deltaTime;

        scoreText.text = $"Score:{score}";
    }
}
