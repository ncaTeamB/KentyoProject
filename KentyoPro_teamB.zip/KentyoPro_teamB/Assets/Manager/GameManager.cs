using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : SingletonMonoBehaviour<GameManager>
{
    [Header("��������")]
    [SerializeField] private float MaxLimitTime = 100;
    [SerializeField] private TextMeshProUGUI timerText;

    [SerializeField] private float limitTimer;

    [Space]
    [Header("�J�n���S")]
    [SerializeField] private GameObject startLogo;

    [Space]
    [Header("�I���{�[�h")]
    [SerializeField] private GameObject finishBoard;

    [Space]
    [Header("�{�b�N�X")]
    [SerializeField] private GameObject[] box;

    [Space]
    public float deltaTime;
    public bool stopTimer;
    public bool ready;

    private float delta;

    private void Start()
    {
        //unity�ݒ�
        Application.targetFrameRate = 60;
        QualitySettings.vSyncCount = 0;

        limitTimer = MaxLimitTime;
        delta = 0;
        stopTimer = false;
        ready = true;

        ////�����_���łQ�{�b�N�X�𐶐�����
        //int i = Random.Range(0, box.Length);
        //Instantiate(box[i], new Vector3(1.5f, 3.75f, 0), Quaternion.Euler(new Vector3(-5, 15, 0)));
        ////���̃{�b�N�X�A�E�Ɣ���Ă����������x�I�тȂ���
        //int r = Random.Range(0, box.Length);
        //while (i == r)
        //    r = Random.Range(0, box.Length);
        //Instantiate(box[r], new Vector3(-1.5f, 3.75f, 0), Quaternion.Euler(new Vector3(-5, 15, 0)));

        StartCoroutine(StartGame());
    }

    void Update()
    {
        deltaTime = Time.deltaTime;
        if (stopTimer == true)
            deltaTime = 0;

        if (ready == true)
            delta += Time.deltaTime;

        if (0 < limitTimer)
            limitTimer -= deltaTime;
        else
        {
            limitTimer = 0;
            FinishGame();
        }

        DrawLimitTimer();
    }

    /// <summary>
    /// �^�C�}�[�̕\��
    /// </summary>
    void DrawLimitTimer()
    {
        if (10 <= limitTimer)
            timerText.text = $"{limitTimer.ToString("f0")}";
        else
        {
            timerText.text = $"{limitTimer.ToString("f1")}";
            timerText.color = Color.red;
        }
    }

    IEnumerator StartGame()
    {
        //Ready
        while (delta < 2)
        {
            stopTimer = true;
            yield return null;
        }

        delta = 0;

        //Start
        stopTimer = false;
        startLogo.SetActive(true);

        while (delta < 1)
        {
            yield return null;
        }
        delta = 0;

        //�X�^�[�g���S�����X�ɏ���
        float alpha = 1;
        while (true)
        {
            alpha = 1 - 1 * delta / 2;
            startLogo.transform.GetComponent<Image>().color = new Color(1, 1, 1, alpha);
            if (alpha <= 0)
                break;

            yield return null;
        }
        startLogo.SetActive(false);

        yield return null;
    }

    void FinishGame()
    {
        GetComponent<TouchManager>().enabled = false;
        finishBoard.SetActive(true);

        Invoke("LoadResult", 3);
    }

    void LoadResult()
    {
        FadeAnimationSceneManager.Instance.LoadScene("ResultScene", 1);
    }

    /// <summary>
    /// �����ɂ͌��炷����(sec)������
    /// </summary>
    /// <param name="decreaseTime"></param>
    public void DecreaseTimer(float decreaseTime)
    {
        limitTimer -= decreaseTime;
    }
}
