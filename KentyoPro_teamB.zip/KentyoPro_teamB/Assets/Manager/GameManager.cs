using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : SingletonMonoBehaviour<GameManager>
{
    [Header("��������")]
    [SerializeField] private float MaxLimitTime = 100;
    [SerializeField] private TextMeshProUGUI timerText;
    private float limitTimer;

    [Space]
    [Header("�X�R�A�\���p�e�L�X�g")]
    [SerializeField] private TextMeshProUGUI scoreText;

    public float deltaTime;
    public bool stopTimer;

    public float score;

    private void Start()
    {
        //unity�ݒ�
        Application.targetFrameRate = 60;
        QualitySettings.vSyncCount = 0;

        limitTimer = MaxLimitTime;
        stopTimer = false;
        score = 0;
    }

    void Update()
    {
        deltaTime = Time.deltaTime;
        if (stopTimer == true)
            deltaTime = 0;

        if (0 < limitTimer)
            limitTimer -= deltaTime;
        else
        {
            limitTimer = 0;
            FinishGame();
        }

        scoreText.text = $"Score:{score}";

        DrawLimitTimer();
    }

    /// <summary>
    /// �^�C�}�[�̕\��
    /// </summary>
    void DrawLimitTimer()
    {
        if (10 <= limitTimer)
            timerText.text = $"Time:{limitTimer.ToString("f0")}";
        else
        {
            timerText.text = $"Time:{limitTimer.ToString("f1")}";
            timerText.color = Color.red;
        }
    }

    void FinishGame()
    {
        SceneManager.LoadScene("TitleScene");
    }

    /// <summary>
    /// �����ɂ͌��炷����(sec)������
    /// </summary>
    /// <param name="decreaseTime"></param>
    public void DecreaseTimer(float decreaseTime)
    {
        limitTimer -= decreaseTime;
    }
}
