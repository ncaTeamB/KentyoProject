using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : SingletonMonoBehaviour<GameManager>
{
    [Header("��������")]
    [SerializeField] private float MaxLimitTime = 100;
    [SerializeField] private TextMeshProUGUI timerText;
    private float limitTimer;

    [Space]
    [Header("�J�n���S")]
    [SerializeField] private GameObject startLogo;

    [Space]
    [Header("�I���{�[�h")]
    [SerializeField] private GameObject finishBoard;

    [Space]
    public float deltaTime;
    public bool stopTimer;

    private bool start;

    private void Start()
    {
        //unity�ݒ�
        Application.targetFrameRate = 60;
        QualitySettings.vSyncCount = 0;

        limitTimer = MaxLimitTime;
        stopTimer = false;
    }

    void Update()
    {
        deltaTime = Time.deltaTime;
        if (stopTimer == true)
            deltaTime = 0;

        if (0 < limitTimer)
            limitTimer -= deltaTime;
        else
        {
            limitTimer = 0;
            FinishGame();
        }

        DrawLimitTimer();
    }

    /// <summary>
    /// �^�C�}�[�̕\��
    /// </summary>
    void DrawLimitTimer()
    {
        if (10 <= limitTimer)
            timerText.text = $"{limitTimer.ToString("f0")}";
        else
        {
            timerText.text = $"{limitTimer.ToString("f1")}";
            timerText.color = Color.red;
        }
    }

    IEnumerator StartGame()
    {
        //Ready

        yield return new WaitForSeconds(3000);

        //Start
        startLogo.SetActive(true);

        yield return new WaitForSeconds(500);

        //�X�^�[�g���S�����X�ɏ���
        while (true)
        {
            yield return null;
        }
        startLogo.SetActive(false);

        yield return null;
    }

    void FinishGame()
    {
        GetComponent<TouchManager>().enabled = false;
        finishBoard.SetActive(true);

        Invoke("LoadTitle", 3);
    }

    void LoadTitle()
    {
        SceneManager.LoadScene("TitleScene");
    }

    /// <summary>
    /// �����ɂ͌��炷����(sec)������
    /// </summary>
    /// <param name="decreaseTime"></param>
    public void DecreaseTimer(float decreaseTime)
    {
        limitTimer -= decreaseTime;
    }
}
