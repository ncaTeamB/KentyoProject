using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : SingletonMonoBehaviour<GameManager>
{
    [Header("��������")]
    [SerializeField] private float MaxLimitTime = 100;
    [SerializeField] private TextMeshProUGUI timerText;

    private float limitTimer;

    [Space]
    [Header("�J�n���S")]
    [SerializeField] private GameObject startLogo;

    [Space]
    [Header("�I���{�[�h")]
    [SerializeField] private GameObject finishBoard;

    [Space]
    public float deltaTime;
    public bool stopTimer;

    private bool start;

    private void Start()
    {
        //unity�ݒ�
        Application.targetFrameRate = 60;
        QualitySettings.vSyncCount = 0;

        limitTimer = MaxLimitTime;
        stopTimer = false;

        StartCoroutine(StartGame());
    }

    void Update()
    {
        deltaTime = Time.deltaTime;
        if (stopTimer == true)
            deltaTime = 0;

        if (0 < limitTimer)
            limitTimer -= deltaTime;
        else
        {
            limitTimer = 0;
            FinishGame();
        }

        DrawLimitTimer();
    }

    /// <summary>
    /// �^�C�}�[�̕\��
    /// </summary>
    void DrawLimitTimer()
    {
        if (10 <= limitTimer)
            timerText.text = $"{limitTimer.ToString("f0")}";
        else
        {
            timerText.text = $"{limitTimer.ToString("f1")}";
            timerText.color = Color.red;
        }
    }

    IEnumerator StartGame()
    {
        //Ready
        stopTimer = true;

        yield return new WaitForSeconds(3);

        //Start
        stopTimer = false;
        startLogo.SetActive(true);

        yield return new WaitForSeconds(1);

        //�X�^�[�g���S�����X�ɏ���
        float time = 0;
        float alpha = 1;
        while (true)
        {
            time += deltaTime;
            alpha = 1 - 1 * time / 2;
            startLogo.transform.GetComponent<Image>().color = new Color(1, 1, 1, alpha);
            if (alpha <= 0)
                break;

            yield return null;
        }
        startLogo.SetActive(false);

        yield return null;
    }

    void FinishGame()
    {
        GetComponent<TouchManager>().enabled = false;
        finishBoard.SetActive(true);

        Invoke("LoadResult", 3);
    }

    void LoadResult()
    {
        SceneManager.LoadScene("ResultScene");
    }

    /// <summary>
    /// �����ɂ͌��炷����(sec)������
    /// </summary>
    /// <param name="decreaseTime"></param>
    public void DecreaseTimer(float decreaseTime)
    {
        limitTimer -= decreaseTime;
    }
}
