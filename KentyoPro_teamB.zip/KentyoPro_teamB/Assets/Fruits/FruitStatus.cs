using UnityEngine;

public class FruitStatus : MonoBehaviour
{
    [Header("���")]
    public string fruitName;

    [Header("�X�R�A")]
    public int fruitScore;

    [HideInInspector]
    public bool touch;
}
