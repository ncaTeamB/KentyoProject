using UnityEngine;

public class FruitStatus : MonoBehaviour
{
    [Header("���")]
    public string fruitName;

    [Header("�X�R�A")]
    public int fruitScore;

    [Header("���鎞��(sec)")]
    [SerializeField] private float maxTime;


    [HideInInspector]
    public bool touch;

    GameObject originObject;
    GameObject rottenObject;

    private float deadTimer;

    private void Start()
    {
        deadTimer = maxTime;
        originObject = this.transform.GetChild(0).gameObject;
        rottenObject = this.transform.GetChild(1).gameObject;
        originObject.SetActive(true);
        rottenObject.SetActive(false);
    }

    private void Update()
    {
        deadTimer -= GameManager.Instance.deltaTime;

        if (deadTimer <= 0)
            DeadProc();
        else if(deadTimer <= 1)
            Rotten();
    }

    void Rotten()
    {
        originObject.SetActive(false);
        rottenObject.SetActive(true);
    }

    void DeadProc()
    {
        Destroy(this.gameObject);
    }
}
