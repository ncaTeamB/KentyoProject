using UnityEngine;

public class FruitStatus : MonoBehaviour
{
    [Header("���")]
    public string fruitName;

    [Header("�X�R�A")]
    public int fruitScore;

    [Header("���鎞��(sec)")]
    [SerializeField] private float maxTime;

    [Header("���������̃e�N�X�`��")]
    [SerializeField] private Material rottenTexture;

    [HideInInspector]
    public bool touch;

    private float deadTimer;

    private void Start()
    {
        deadTimer = maxTime;
    }

    private void Update()
    {
        deadTimer -= GameManager.Instance.deltaTime;

        if (deadTimer <= 0)
            DeadProc();
        else if(deadTimer <= 1)
            ChangeTexture();
    }

    void ChangeTexture()
    {
        this.transform.GetComponent<Renderer>().material = rottenTexture;
    }

    void DeadProc()
    {
        Destroy(this.gameObject);
    }
}
