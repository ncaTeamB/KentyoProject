using UnityEngine;

public class FruitsJenerater : MonoBehaviour
{
    [Header("�o���͈�")]
    [SerializeField] private int maxR;

    [Space]
    [Header("�o������")]
    [SerializeField] private float intervalTime;

    [Space]
    [Header("�o�����Ԃ̌���")]
    [SerializeField] private float acceleratorTime;

    [Space]
    [Header("�o�Ă���t���[�c")]
    [SerializeField] private GameObject fruits;

    private float time;
    private float firstInterval;
    private const float minInterval = 1f;

    private int saveScore;

    private void Start()
    {
        firstInterval = Random.Range(1.0f, 5.0f);

        saveScore = ScoreManager.score;
    }

    void Update()
    {
        time += GameManager.Instance.deltaTime;

        //����̂ݎ��s
        if (0 < firstInterval && firstInterval < time)
        {
            float randX = Random.Range(maxR * -1.0f, maxR);
            float randY = Random.Range(maxR * -1.0f, maxR);
            Instantiate(fruits, new Vector2(randX, randY), Quaternion.identity);

            firstInterval = -1;
            time = 0;
        }
        else if (intervalTime < time)
        {
            float randX = Random.Range(maxR * -1.0f, maxR);
            float randY = Random.Range(maxR * -1.0f, maxR);
            Instantiate(fruits, new Vector2(randX, randY), Quaternion.identity);

            //�Ԋu��Z������
            if (minInterval < intervalTime)
            {
                //�X�R�A���O����オ���Ă�������s
                if (saveScore < ScoreManager.score)
                {
                    intervalTime -= acceleratorTime;
                    saveScore = ScoreManager.score;
                }
            }
            else
                intervalTime = minInterval;

            time = 0;
        }
    }
}
