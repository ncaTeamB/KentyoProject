using UnityEngine;

public class FruitsJenerater : MonoBehaviour
{
    [Header("�o���͈�")]
    [SerializeField] private int maxR;

    [Space]
    [Header("�o������")]
    [SerializeField] private float intervalTime;

    [Space]
    [Header("�o�����Ԃ̌���")]
    [SerializeField] private float acceleratorTime;

    [Space]
    [Header("�o�Ă���t���[�c")]
    [SerializeField] private GameObject fruits;

    private float time;
    private const float minInterval = 1f;

    private void Start()
    {
        if (intervalTime < minInterval)
            intervalTime = minInterval;
    }

    void Update()
    {
        time += GameManager.Instance.deltaTime;

        if (intervalTime < time)
        {
            float randX = Random.Range(maxR * -1.0f, maxR);
            float randY = Random.Range(maxR * -1.0f, maxR);
            Instantiate(fruits, new Vector2(randX, randY), Quaternion.identity);

            //�Ԋu��Z������
            if (minInterval < intervalTime)
                intervalTime -= acceleratorTime;
            else
                intervalTime = minInterval;

            time = 0;
        }
    }
}
