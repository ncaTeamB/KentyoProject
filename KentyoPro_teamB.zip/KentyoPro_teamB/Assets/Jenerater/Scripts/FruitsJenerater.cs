using UnityEngine;

public class FruitsJenerater : MonoBehaviour
{
    [Header("�o���͈�")]
    [SerializeField] private int maxR;

    [Space]
    [Header("�o������")]
    [SerializeField] private float maxIntervalTime;
    [SerializeField] private float minIntervalTime;

    [Space]
    [Header("�o�����Ԃ̌���")]
    [SerializeField] private float acceleratorTime;

    [Space]
    [Header("�o�Ă���t���[�c")]
    [SerializeField] private GameObject fruits;

    private float time;
    private float intervalTime;
    private const float min = 1f;

    private int saveScore;

    private void Start()
    {
        intervalTime = Random.Range(1.0f, 5.0f);

        saveScore = ScoreManager.score;
    }

    void Update()
    {
        time += GameManager.Instance.deltaTime;

        //�Ԋu�������Ď��s
        if (intervalTime < time)
        {
            float randX = Random.Range(maxR * -1.0f, maxR);
            float randY = Random.Range(maxR * -1.0f, maxR);
            //�t���[�c�Ɣ�������蒼��
            while (CheckOtherPos(randX, randY) == false)
            {
                randX = Random.Range(maxR * -1.0f, maxR);
                randY = Random.Range(maxR * -1.0f, maxR);
            }

            Instantiate(fruits, new Vector2(this.transform.position.x + randX, this.transform.position.y + randY), Quaternion.identity);

            //�Ԋu��Z������
            if (min < minIntervalTime)
            {
                //�X�R�A���O����オ���Ă�������s
                if (saveScore < ScoreManager.score)
                {
                    //�������X�R�A���X�s�[�h�A�b�v������
                    int rate = ScoreManager.score - saveScore;
                    minIntervalTime -= acceleratorTime * rate;
                    maxIntervalTime -= acceleratorTime * rate;

                    saveScore = ScoreManager.score;
                }
            }

            intervalTime = Random.Range(maxIntervalTime, minIntervalTime);

            time = 0;
        }
    }

    /// <summary>
    /// �ق��̃t���[�c�Ɣ���Ă��Ȃ����treu��Ԃ�
    /// </summary>
    bool CheckOtherPos(float rX, float rY)
    {
        const float distance = 1f;
        Vector3 pos = this.transform.position;
        pos.x += rX;
        pos.y += rY;

        GameObject[] fruits = GameObject.FindGameObjectsWithTag("Fruit");
        foreach (GameObject f in fruits)
        {
            if (Vector3.Distance(pos, f.transform.position) < distance)
                return false;
        }

        return true;
    }
}
