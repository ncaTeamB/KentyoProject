using UnityEngine;

public class TouchManager : MonoBehaviour
{
    [SerializeField] private bool touch = false;

    private GameObject catchOb;
    private Vector3 catchMousePos;

    Vector2 dif;
    private bool init = false;

    void Start()
    {

    }

    void Update()
    {
        DragAndDropController();
    }

    void DragAndDropController()
    {
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePos.z = -8;
        if (Input.GetMouseButtonDown(0))
        {
            const int direction = 10;

            Ray ray = new Ray(mousePos, new Vector3(0, 0, 1) * direction);
            RaycastHit hit;
            Debug.DrawRay(ray.origin, ray.direction, Color.red, 1);

            if (Physics.Raycast(ray.origin, ray.direction, out hit))
            {
                catchOb = hit.collider.gameObject;
                catchMousePos = mousePos - catchOb.transform.position;
            }
        }
        else if (Input.GetMouseButtonUp(0))
        {
            catchOb = null;
        }
        else if (catchOb != null)
        {
            mousePos.z = 0;
            catchOb.transform.position = mousePos - catchMousePos;
        }
    }
}
